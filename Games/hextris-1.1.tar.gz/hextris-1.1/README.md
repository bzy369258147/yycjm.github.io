Hextris
==========

Built by @teamsnowman (@meadowstream, @garrettdreyfus, @nmoroze, and @themichaelyang) for HackExeter 2014

# Releases
#### iOS: https://itunes.apple.com/us/app/hextris/id903769553?mt=8
![](http://i.imgur.com/KBYZcf5.png)

#### Android: https://play.google.com/store/apps/details?id=com.hextris.hextris
![](http://i.imgur.com/mxj8yKs.png)

## Press kit

hextris.github.io/presskit/info.html

## License

This work is under a GPL license.
